export default function Page() {
  return (
    <div className="container-narrow py-10">
      <h1 className="text-2xl font-semibold mb-4">Selamat datang di SIT</h1>
      <p className="text-gray-600">Silakan ajukan transkrip atau masuk ke akun Anda.</p>
    </div>
  )
}
